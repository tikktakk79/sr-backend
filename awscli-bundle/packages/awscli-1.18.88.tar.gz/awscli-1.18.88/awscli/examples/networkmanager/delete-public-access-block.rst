**To delete the block public access configuration for a bucket**

The following ``delete-public-access-block`` example removes the block public access configuration on the specified bucket. ::

    aws s3api delete-public-access-block \
        --bucket my-bucket

This command produces no output.
